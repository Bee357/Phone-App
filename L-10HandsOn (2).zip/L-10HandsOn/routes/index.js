var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
var express = require('express');
//var router = express.Router();
//var staticModels = require('../staticModels/users');

//router.get('/staticUsers', function (req, res, next) {

  res.send(JSON.stringify(
    staticModels.user
  ));
});

module.exports = router;
